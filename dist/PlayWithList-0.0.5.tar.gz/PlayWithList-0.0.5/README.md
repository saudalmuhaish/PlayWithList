# PlayWithList
User can enter the list and get many function of it.
